package com.cookandroid.tetrisgame;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class GameOverActivity extends AppCompatActivity {

    private TextView gameOverText, scoreText, timeText;
    private Button restartButton, homeButton;
    private boolean isTimeAttackMode;  // 타임어택 모드 여부
    private long elapsedTime;  // 타임어택 모드에서 걸린 시간
    private int score;
    private String mode;  // 게임 모드 (노말 모드 / 타임어택 모드)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);

        // UI 요소 초기화
        gameOverText = findViewById(R.id.gameOverText);
        scoreText = findViewById(R.id.scoreText);
        timeText = findViewById(R.id.timeText);
        restartButton = findViewById(R.id.restartButton);
        homeButton = findViewById(R.id.homeButton);

        // 인텐트로 전달받은 정보 처리
        score = getIntent().getIntExtra("score", 0);
        elapsedTime = getIntent().getLongExtra("elapsedTime", 0); // 타임어택 모드에서 걸린 시간
        mode = getIntent().getStringExtra("mode");  // 전달받은 모드 (노말 모드 / 타임어택 모드)
        String gameResult = getIntent().getStringExtra("gameResult");

        // 게임 결과에 따라 텍스트 변경
        if ("success".equals(gameResult)) {
            gameOverText.setText("게임 성공!");
        } else {
            gameOverText.setText("게임 오버!");
        }

        // 점수 표시
        scoreText.setText("Score: " + score);

        // 타임어택 모드일 경우 시간 표시
        if (elapsedTime > 0) {
            isTimeAttackMode = true;
            timeText.setText("Time: " + elapsedTime / 1000 + "s");
        } else {
            timeText.setVisibility(TextView.INVISIBLE); // 노말 모드일 경우 시간 숨기기
        }

        // "다시하기" 버튼 클릭 시
        restartButton.setOnClickListener(v -> {
            // 게임 모드에 따라 다시 시작할 액티비티 결정
            Intent intent;
            if ("normal".equals(mode)) {
                // 노말 모드로 다시 시작
                intent = new Intent(GameOverActivity.this, NormalModeActivity.class);
            } else if ("time_attack".equals(mode)) {
                // 타임어택 모드로 다시 시작
                intent = new Intent(GameOverActivity.this, TimeAttackModeActivity.class);
            } else {
                // 기본적으로 타임어택 모드로 시작
                intent = new Intent(GameOverActivity.this, TimeAttackModeActivity.class);
            }
            startActivity(intent);
            finish();
        });

        // "처음으로" 버튼 클릭 시
        homeButton.setOnClickListener(v -> {
            // 메인 화면으로 이동
            Intent intent = new Intent(GameOverActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
