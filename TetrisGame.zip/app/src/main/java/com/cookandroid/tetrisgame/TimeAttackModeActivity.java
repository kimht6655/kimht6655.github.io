package com.cookandroid.tetrisgame;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class TimeAttackModeActivity extends AppCompatActivity {
    private GridLayout gameGrid;
    private TextView scoreText, timeText;
    private int[][] gridMatrix = new int[20][10];
    private View[][] cellViews = new View[20][10];
    private Handler gameHandler;
    private Runnable gameLoop;

    private int score = 0;
    private int clearedLines = 0;  // 지운 줄 수
    private int[][] currentBlock;
    private int blockX = 4, blockY = 0;

    private boolean isGameOver = false; // 게임 오버 상태 플래그

    private long startTime;
    private long elapsedTime = 0;

    private final int[][][] blockShapes = {
            {{1, 1, 1, 1}},
            {{1, 1}, {1, 1}},
            {{0, 1, 0}, {1, 1, 1}},
            {{0, 1, 1}, {1, 1, 0}},
            {{1, 1, 0}, {0, 1, 1}},
            {{1, 0, 0}, {1, 1, 1}},
            {{0, 0, 1}, {1, 1, 1}}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_attack_mode);

        gameGrid = findViewById(R.id.gameGrid);
        scoreText = findViewById(R.id.scoreText);
        timeText = findViewById(R.id.timeText);

        Button leftButton = findViewById(R.id.leftButton);
        Button rightButton = findViewById(R.id.rightButton);
        Button downButton = findViewById(R.id.downButton);
        Button rotateButton = findViewById(R.id.rotateButton);

        // 초기화 작업
        initializeGrid();

        // 버튼 이벤트 설정
        leftButton.setOnClickListener(v -> moveBlock(-1, 0));
        rightButton.setOnClickListener(v -> moveBlock(1, 0));
        downButton.setOnClickListener(v -> moveBlock(0, 1));
        rotateButton.setOnClickListener(v -> rotateBlock());

        // 게임 루프 설정
        gameHandler = new Handler();
        gameLoop = new Runnable() {
            @Override
            public void run() {
                updateGame();
                gameHandler.postDelayed(this, 500);
            }
        };
        gameHandler.post(gameLoop);

        // 게임 시작 시간 기록
        startTime = System.currentTimeMillis();
    }

    private void initializeGrid() {
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        int cellSize = 90;

        for (int i = 0; i < 20; i++) {
            for (int j = 0; j < 10; j++) {
                View cell = new View(this);
                cell.setBackgroundColor(Color.DKGRAY);

                GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                params.rowSpec = GridLayout.spec(i);
                params.columnSpec = GridLayout.spec(j);
                params.width = cellSize;
                params.height = cellSize;
                params.setMargins(1, 1, 1, 1);
                cell.setLayoutParams(params);

                gameGrid.addView(cell);
                cellViews[i][j] = cell;
            }
        }
        spawnBlock();
    }

    private void spawnBlock() {
        Random random = new Random();
        currentBlock = blockShapes[random.nextInt(blockShapes.length)];
        blockX = 4;
        blockY = 0;
    }

    private void updateGame() {
        elapsedTime = System.currentTimeMillis() - startTime;
        timeText.setText("Time: " + (elapsedTime / 1000) + "s"); // 시간을 초 단위로 표시

        if (!moveBlock(0, 1)) {
            mergeBlock();
            clearLines();
            spawnBlock();
            if (checkGameOver()) {
                if (!isGameOver) { // 게임 오버가 아직 처리되지 않았다면
                    gameHandler.removeCallbacks(gameLoop);
                    scoreText.setText("Game Over! Score: " + score);
                    gameOver();  // 게임 오버 처리
                    isGameOver = true; // 게임 오버 상태 설정
                }
                return;
            }
        }
        scoreText.setText("Score: " + score);
        drawGrid();
    }

    private void gameOver() {
        // 게임 오버 상태로 설정
        isGameOver = true;

        // 게임 루프 중지
        gameHandler.removeCallbacks(gameLoop); // 게임 루프를 중지

        Intent intent = new Intent(TimeAttackModeActivity.this, GameOverActivity.class);
        intent.putExtra("score", score); // 점수 전달
        intent.putExtra("elapsedTime", elapsedTime); // 시간 전달
        intent.putExtra("mode", "time_attack"); // 게임 모드 정보를 전달 (타임어택 모드)
        startActivity(intent);
        finish(); // 현재 액티비티 종료
    }


    private boolean moveBlock(int dx, int dy) {
        if (!isValidMove(blockX + dx, blockY + dy, currentBlock)) {
            return false;
        }
        blockX += dx;
        blockY += dy;
        return true;
    }

    private boolean isValidMove(int x, int y, int[][] block) {
        for (int i = 0; i < block.length; i++) {
            for (int j = 0; j < block[i].length; j++) {
                if (block[i][j] != 0) {
                    int nx = x + j;
                    int ny = y + i;
                    if (nx < 0 || nx >= 10 || ny < 0 || ny >= 20 || gridMatrix[ny][nx] != 0) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    private void mergeBlock() {
        for (int i = 0; i < currentBlock.length; i++) {
            for (int j = 0; j < currentBlock[i].length; j++) {
                if (currentBlock[i][j] != 0) {
                    gridMatrix[blockY + i][blockX + j] = currentBlock[i][j];
                }
            }
        }
    }

    private void clearLines() {
        for (int i = 0; i < 20; i++) {
            boolean fullLine = true;
            for (int j = 0; j < 10; j++) {
                if (gridMatrix[i][j] == 0) {
                    fullLine = false;
                    break;
                }
            }
            if (fullLine) {
                clearedLines++;  // 지운 줄 수 증가
                for (int k = i; k > 0; k--) {
                    gridMatrix[k] = gridMatrix[k - 1].clone();
                }
                gridMatrix[0] = new int[10];
                score += 100;
            }
        }
        // clearedLines >= ( x )  x를 수정해  x 줄을 지우면 게임 오버 로 설정
        if (clearedLines >= 5 ) {
            gameOver();
        }
    }

    private boolean checkGameOver() {
        for (int j = 0; j < 10; j++) {
            if (gridMatrix[0][j] != 0) {
                return true;
            }
        }
        return false;
    }

    private void drawGrid() {
        for (int i = 0; i < 20; i++) {
            for (int j = 0; j < 10; j++) {
                if (gridMatrix[i][j] != 0) {
                    cellViews[i][j].setBackgroundColor(Color.CYAN);
                } else {
                    cellViews[i][j].setBackgroundColor(Color.DKGRAY);
                }
            }
        }
        for (int i = 0; i < currentBlock.length; i++) {
            for (int j = 0; j < currentBlock[i].length; j++) {
                if (currentBlock[i][j] != 0) {
                    int nx = blockX + j;
                    int ny = blockY + i;
                    if (ny >= 0 && ny < 20 && nx >= 0 && nx < 10) {
                        cellViews[ny][nx].setBackgroundColor(Color.CYAN);
                    }
                }
            }
        }
    }

    private void rotateBlock() {
        int[][] rotatedBlock = new int[currentBlock[0].length][currentBlock.length];
        for (int i = 0; i < currentBlock.length; i++) {
            for (int j = 0; j < currentBlock[i].length; j++) {
                rotatedBlock[j][currentBlock.length - 1 - i] = currentBlock[i][j];
            }
        }
        if (isValidMove(blockX, blockY, rotatedBlock)) {
            currentBlock = rotatedBlock;
        }
    }
}
