package com.cookandroid.tetrisgame;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.cookandroid.tetrisgame.NormalModeActivity;
import com.cookandroid.tetrisgame.TimeAttackModeActivity;

public class GameModeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_mode);

        Button btnNormalMode = findViewById(R.id.btnNormalMode);
        Button btnTimeAttackMode = findViewById(R.id.btnTimeAttackMode);

        // Normal Mode 버튼 클릭
        btnNormalMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GameModeActivity.this, NormalModeActivity.class);
                startActivity(intent);
            }
        });

        // Time Attack Mode 버튼 클릭
        btnTimeAttackMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GameModeActivity.this, TimeAttackModeActivity.class);
                startActivity(intent);
            }
        });
    }
}
